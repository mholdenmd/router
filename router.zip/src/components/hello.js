import React from 'react';

const Hello = () => {


     
        return (
            <div>
                
                <h1>placeholder for Hello</h1>
            </div>
        );
    
};
export default Hello;