import React from 'react';

const HomePage = () => {


     
        return (
            <div>
                <h1>placeholder 1</h1>
            </div>
        );
    
};
export default HomePage;